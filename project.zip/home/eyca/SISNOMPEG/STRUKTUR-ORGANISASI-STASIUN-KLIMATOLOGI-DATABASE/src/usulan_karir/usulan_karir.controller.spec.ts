import { Test, TestingModule } from '@nestjs/testing';
import { UsulanKarirController } from './usulan_karir.controller';

describe('UsulanKarirController', () => {
  let controller: UsulanKarirController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [UsulanKarirController],
    }).compile();

    controller = module.get<UsulanKarirController>(UsulanKarirController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});

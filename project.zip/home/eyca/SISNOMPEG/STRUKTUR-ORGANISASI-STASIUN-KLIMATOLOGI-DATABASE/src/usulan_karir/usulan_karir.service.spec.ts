import { Test, TestingModule } from '@nestjs/testing';
import { UsulanKarirService } from './usulan_karir.service';

describe('UsulanKarirService', () => {
  let service: UsulanKarirService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [UsulanKarirService],
    }).compile();

    service = module.get<UsulanKarirService>(UsulanKarirService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});

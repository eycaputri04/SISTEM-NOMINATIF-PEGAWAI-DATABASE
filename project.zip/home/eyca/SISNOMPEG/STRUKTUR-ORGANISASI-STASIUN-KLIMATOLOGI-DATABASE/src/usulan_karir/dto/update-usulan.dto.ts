import { PartialType } from '@nestjs/swagger';
import { CreateUsulanKarirDto } from './create-usulan.dto';

export class UpdateUsulanKarirDto extends PartialType(CreateUsulanKarirDto) {}

import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsOptional, IsString, IsUUID, IsDateString } from 'class-validator';

export class CreateUsulanKarirDto {
  @ApiProperty({
    example: 'f7c0b1a2-12d3-4a45-bcd6-89b1a9f7d3f2',
    description: 'ID unik untuk data usulan karir',
  })
  @IsOptional()
  @IsUUID()
  ID_Usulan?: string;

  @ApiProperty({
    example: '1987654321',
    description: 'NIP Pegawai yang diusulkan',
  })
  @IsNotEmpty()
  @IsString()
  Pegawai: string;

  @ApiProperty({
    example: 'Kenaikan Pangkat',
    description: 'Jenis usulan yang diajukan (misalnya: Kenaikan Pangkat, Mutasi, dll)',
  })
  @IsNotEmpty()
  @IsString()
  Jenis_Usulan: string;

  @ApiProperty({
    example: 'Analis Cuaca Madya',
    description: 'Pangkat atau jabatan tujuan dari usulan karir',
  })
  @IsOptional()
  @IsString()
  Pangkat_Jabatan_Tujuan?: string;

  @ApiProperty({
    example: '2025-01-15',
    description: 'Tanggal usulan diajukan',
  })
  @IsNotEmpty()
  @IsDateString()
  Tanggal_Usulan: string;

  @ApiProperty({
    example: 'Diproses',
    description: 'Status usulan saat ini (misalnya: Diproses, Disetujui, Ditolak)',
  })
  @IsOptional()
  @IsString()
  Status_Usulan?: string;

  @ApiProperty({
    example: 'Menunggu persetujuan pimpinan',
    description: 'Catatan tambahan terkait usulan karir',
  })
  @IsOptional()
  @IsString()
  Catatan?: string;
}

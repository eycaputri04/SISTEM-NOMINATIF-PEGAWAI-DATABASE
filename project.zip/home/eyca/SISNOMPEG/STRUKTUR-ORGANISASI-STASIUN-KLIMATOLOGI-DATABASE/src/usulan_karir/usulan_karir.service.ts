import { Injectable, BadRequestException } from '@nestjs/common';
import { supabase } from '../supabase/supabase.client';
import { CreateUsulanKarirDto } from './dto/create-usulan.dto';
import { UpdateUsulanKarirDto } from './dto/update-usulan.dto';
import { logAktivitas } from '../utils/logAktivitas';

@Injectable()
export class UsulanKarirService {
  private readonly table = 'Usulan_Karir';

  /** CREATE */
  async create(createDto: CreateUsulanKarirDto) {
    const { data, error } = await supabase
      .from(this.table)
      .insert([createDto])
      .select()
      .maybeSingle();

    if (error) {
      console.error('Supabase error:', error);
      throw new BadRequestException(`Gagal menambahkan data usulan karir: ${error.message}`);
    }

    if (!data) {
      throw new BadRequestException('Data usulan karir gagal ditambahkan');
    }

    await logAktivitas(
      'Usulan_Karir',
      'Menambahkan data usulan karir',
      `Menambahkan usulan karir untuk pegawai ${createDto.Pegawai}`
    );

    return {
      message: 'Data usulan karir berhasil ditambahkan',
      data,
    };
  }

  /** UPDATE */
  async update(id: string, updateDto: UpdateUsulanKarirDto) {
    const { data, error } = await supabase
      .from(this.table)
      .update(updateDto)
      .eq('ID_Usulan', id)
      .select()
      .maybeSingle();

    if (error) {
      throw new BadRequestException(`Gagal memperbarui data usulan karir: ${error.message}`);
    }

    if (!data) {
      throw new BadRequestException('Data usulan karir tidak ditemukan');
    }

    await logAktivitas(
      'Usulan_Karir',
      'Memperbarui data usulan karir',
      `Memperbarui usulan karir untuk pegawai ${data.Pegawai}`
    );

    return {
      message: 'Data usulan karir berhasil diperbarui',
      data,
    };
  }

  /** READ ALL */
  async findAll() {
    const { data, error } = await supabase.from(this.table).select('*');
    if (error) throw new BadRequestException('Gagal mengambil data usulan karir');
    return data;
  }

  /** READ ONE */
  async findOne(id: string) {
    const { data, error } = await supabase
      .from(this.table)
      .select('*')
      .eq('ID_Usulan', id)
      .maybeSingle();

    if (error) throw new BadRequestException('Gagal mengambil data usulan karir');
    if (!data) throw new BadRequestException('Data usulan karir tidak ditemukan');
    return data;
  }

  /** DELETE */
  async remove(id: string) {
    const { error } = await supabase.from(this.table).delete().eq('ID_Usulan', id);
    if (error) throw new BadRequestException('Gagal menghapus data usulan karir');

    await logAktivitas(
      'Usulan_Karir',
      'Menghapus data usulan karir',
      `Menghapus usulan karir dengan ID ${id}`
    );

    return { message: 'Data usulan karir berhasil dihapus' };
  }
}

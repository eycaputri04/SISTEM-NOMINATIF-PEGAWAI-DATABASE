import { Module } from '@nestjs/common';
import { UsulanKarirController } from './usulan_karir.controller';
import { UsulanKarirService } from './usulan_karir.service';

@Module({
  controllers: [UsulanKarirController],
  providers: [UsulanKarirService]
})
export class UsulanKarirModule {}

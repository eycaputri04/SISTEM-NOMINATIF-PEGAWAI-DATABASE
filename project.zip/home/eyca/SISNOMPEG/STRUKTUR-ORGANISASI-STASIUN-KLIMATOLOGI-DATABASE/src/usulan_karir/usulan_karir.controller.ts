import {
  Controller,
  Post,
  Get,
  Body,
  Param,
  Put,
  Delete,
  BadRequestException,
} from '@nestjs/common';
import { UsulanKarirService } from './usulan_karir.service';
import { CreateUsulanKarirDto } from './dto/create-usulan.dto';
import { UpdateUsulanKarirDto } from './dto/update-usulan.dto';
import { ApiTags, ApiOperation, ApiResponse } from '@nestjs/swagger';

@ApiTags('Usulan Karir')
@Controller('usulan-karir')
export class UsulanKarirController {
  constructor(private readonly usulanKarirService: UsulanKarirService) {}

  @Post()
  @ApiOperation({ summary: 'Menambahkan data usulan karir baru' })
  @ApiResponse({ status: 201, description: 'Data usulan karir berhasil ditambahkan' })
  async create(@Body() body: CreateUsulanKarirDto) {
    try {
      const result = await this.usulanKarirService.create(body);
      return result;
    } catch (error) {
      console.error('Error detail:', error);
      throw new BadRequestException('Gagal menambahkan data usulan karir');
    }
  }

  @Get()
  @ApiOperation({ summary: 'Mengambil semua data usulan karir' })
  findAll() {
    return this.usulanKarirService.findAll();
  }

  @Get(':id')
  @ApiOperation({ summary: 'Mengambil data usulan karir berdasarkan ID' })
  findOne(@Param('id') id: string) {
    return this.usulanKarirService.findOne(id);
  }

  @Put(':id')
  @ApiOperation({ summary: 'Memperbarui data usulan karir berdasarkan ID' })
  update(@Param('id') id: string, @Body() dto: UpdateUsulanKarirDto) {
    return this.usulanKarirService.update(id, dto);
  }

  @Delete(':id')
  @ApiOperation({ summary: 'Menghapus data usulan karir berdasarkan ID' })
  remove(@Param('id') id: string) {
    return this.usulanKarirService.remove(id);
  }
}

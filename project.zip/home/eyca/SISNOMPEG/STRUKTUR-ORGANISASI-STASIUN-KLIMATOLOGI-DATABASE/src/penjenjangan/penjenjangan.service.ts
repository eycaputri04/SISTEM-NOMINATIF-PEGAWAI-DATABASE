import { Injectable, BadRequestException } from '@nestjs/common';
import { supabase } from '../supabase/supabase.client';
import { CreatePenjenjanganDto } from './dto/create-penjenjangan.dto';
import { UpdatePenjenjanganDto } from './dto/update-penjenjangan.dto';
import { logAktivitas } from '../utils/logAktivitas';

@Injectable()
export class PenjenjanganService {
  private readonly table = 'penjenjangan';

  /** CREATE Penjenjangan */
  async create(createDto: CreatePenjenjanganDto) {
    const { data, error } = await supabase
      .from(this.table)
      .insert([createDto])
      .select()
      .maybeSingle();

    if (error) {
      console.error('Supabase insert error:', error);
      throw new BadRequestException(
        `Gagal menambahkan data penjenjangan: ${error.message}`,
      );
    }

    if (!data) {
      throw new BadRequestException('Data penjenjangan gagal ditambahkan');
    }

    await logAktivitas(
      'penjenjangan',
      'Menambahkan data penjenjangan',
      `Menambahkan penjenjangan untuk pegawai ${createDto.Pegawai}`,
    );

    return {
      message: 'Data penjenjangan berhasil ditambahkan',
      data,
    };
  }

  /** READ ALL Penjenjangan */
  async findAll() {
    const { data, error } = await supabase.from(this.table).select('*');

    if (error) {
      console.error('Supabase select error:', error);
      throw new BadRequestException('Gagal mengambil data penjenjangan');
    }

    return data;
  }

  /** READ ONE Penjenjangan */
  async findOne(id: string) {
    const { data, error } = await supabase
      .from(this.table)
      .select('*')
      .eq('ID_Penjenjangan', id)
      .maybeSingle();

    if (error) {
      console.error('Supabase findOne error:', error);
      throw new BadRequestException('Gagal mengambil data penjenjangan');
    }

    if (!data) {
      throw new BadRequestException('Data penjenjangan tidak ditemukan');
    }

    return data;
  }

  /** UPDATE Penjenjangan */
  async update(id: string, dto: UpdatePenjenjanganDto) {
    const { data, error } = await supabase
      .from(this.table)
      .update(dto)
      .eq('ID_Penjenjangan', id)
      .select()
      .maybeSingle();

    if (error) {
      console.error(' Supabase update error:', error);
      throw new BadRequestException(
        `Gagal memperbarui data penjenjangan: ${error.message}`,
      );
    }

    if (!data) {
      throw new BadRequestException('Data penjenjangan gagal diperbarui');
    }

    await logAktivitas(
      'penjenjangan',
      'Memperbarui data penjenjangan',
      `Memperbarui penjenjangan dengan ID ${id}`,
    );

    return {
      message: 'Data penjenjangan berhasil diperbarui',
      data,
    };
  }

  /** DELETE Penjenjangan */
  async remove(id: string) {
    const { error } = await supabase
      .from(this.table)
      .delete()
      .eq('ID_Penjenjangan', id);

    if (error) {
      console.error('Supabase delete error:', error);
      throw new BadRequestException('Gagal menghapus data penjenjangan');
    }

    await logAktivitas(
      'penjenjangan',
      'Menghapus data penjenjangan',
      `Menghapus penjenjangan dengan ID ${id}`,
    );

    return { message: 'Data penjenjangan berhasil dihapus' };
  }

  /** COUNT Total Data */
  async getCount() {
    const { count, error } = await supabase
      .from(this.table)
      .select('*', { count: 'exact', head: true });

    if (error) {
      console.error('Supabase count error:', error);
      throw new BadRequestException('Gagal mengambil total penjenjangan');
    }

    return { count: count ?? 0 };
  }
}

import { Controller, Get, BadRequestException } from '@nestjs/common';
import { supabase } from '../supabase/supabase.client';

@Controller('aktivitas')
export class AktivitasController {
  @Get('terbaru')
  async getRecent() {
    const { data: allData, error } = await supabase
      .from('aktivitas') 
      .select('id, modul, aksi, waktu, deskripsi')
      .order('waktu', { ascending: false });

    if (error) throw new BadRequestException(error.message);

    // Ambil 3 terbaru
    const terbaru = allData.slice(0, 3);

    // Hapus sisanya jika lebih dari 3
    const sisanya = allData.slice(3);
    if (sisanya.length > 0) {
      const idsToDelete = sisanya.map((item) => item.id);
      await supabase.from('aktivitas').delete().in('id', idsToDelete); 
    }

    // Format untuk frontend
    const formatted = terbaru.map((item) => ({
      jenis: item.aksi,        
      waktu: item.waktu,
      keterangan: item.deskripsi,
    }));

    return formatted;
  }
}

import { Injectable, BadRequestException } from '@nestjs/common';
import { supabase } from '../supabase/supabase.client';
import { CreateStrukturDto } from './dto/create-struktur.dto';
import { logAktivitas } from '../utils/logAktivitas';

@Injectable()
export class StrukturService {
  private readonly table = 'struktur';

  // CREATE
  async create(createStrukturDto: CreateStrukturDto) {
    const { data, error } = await supabase
      .from(this.table)
      .insert([createStrukturDto])
      .select()
      .maybeSingle();

    if (error) {
      throw new BadRequestException(`Gagal menambahkan struktur: ${error.message}`);
    }

    if (!data) {
      throw new BadRequestException('Struktur gagal ditambahkan');
    }

    await logAktivitas(
      'Struktur',
      'Menambahkan struktur',
      `Menambahkan struktur untuk pegawai ${createStrukturDto.Pegawai}`
    );

    return {
      message: 'Struktur berhasil ditambahkan',
      data,
    };
  }

  // UPDATE
  async update(id: string, updateDto: Partial<CreateStrukturDto>) {
    const { data, error } = await supabase
      .from(this.table)
      .update(updateDto)
      .eq('ID_Struktur', id)
      .select()
      .maybeSingle();

    if (error) {
      throw new BadRequestException(`Gagal memperbarui struktur: ${error.message}`);
    }

    if (!data) {
      throw new BadRequestException('Struktur tidak ditemukan');
    }

    await logAktivitas(
      'Struktur',
      'Memperbarui struktur',
      `Memperbarui struktur untuk pegawai ${data.Pegawai}`
    );

    return {
      message: 'Struktur berhasil diperbarui',
      data,
    };
  }

  // READ ALL
  async findAll() {
    const { data, error } = await supabase.from(this.table).select('*');
    if (error) {
      throw new BadRequestException('Gagal mengambil data struktur');
    }
    return data;
  }

  // READ ONE
  async findOne(id: string) {
    const { data, error } = await supabase
      .from(this.table)
      .select('*')
      .eq('ID_Struktur', id)
      .maybeSingle();

    if (error) {
      throw new BadRequestException('Gagal mengambil data struktur');
    }

    if (!data) {
      throw new BadRequestException('Struktur tidak ditemukan');
    }

    return data;
  }

  // COUNT
  async getCount() {
    const { count, error } = await supabase
      .from(this.table)
      .select('*', { count: 'exact', head: true });

    if (error) {
      throw new BadRequestException('Gagal mengambil total struktur');
    }

    return { count: count ?? 0 };
  }

  // DELETE
  async remove(id: string) {
    const { error } = await supabase.from(this.table).delete().eq('ID_Struktur', id);

    if (error) {
      throw new BadRequestException('Gagal menghapus struktur');
    }

    await logAktivitas(
      'Struktur',
      'Menghapus struktur',
      `Menghapus struktur dengan ID ${id}`
    );

    return { message: 'Struktur berhasil dihapus' };
  }
}

import {
  Controller,
  Post,
  Get,
  Body,
  Param,
  Put,
  Delete,
  BadRequestException,
} from '@nestjs/common';
import { PendidikanService } from './pendidikan.service';
import { CreatePendidikanDto } from './dto/create-pendidikan.dto';
import { UpdatePendidikanDto } from './dto/update-pendidikan.dto';
import { ApiTags, ApiOperation, ApiResponse } from '@nestjs/swagger';

@ApiTags('Pendidikan')
@Controller('pendidikan')
export class PendidikanController {
  constructor(private readonly pendidikanService: PendidikanService) {}

  // Tambah data pendidikan
  @Post()
  @ApiOperation({ summary: 'Menambahkan data pendidikan baru' })
  @ApiResponse({ status: 201, description: 'Data pendidikan berhasil ditambahkan' })
  async create(@Body() body: CreatePendidikanDto) {
    try {
      console.log('Data diterima:', body);
      const result = await this.pendidikanService.create(body);
      console.log('Hasil insert:', result);
      return result;
    } catch (error) {
      console.error('Error detail:', error);
      throw new BadRequestException('Gagal menambahkan data pendidikan');
    }
  }

  // Ambil semua data pendidikan
  @Get()
  @ApiOperation({ summary: 'Mengambil semua data pendidikan' })
  @ApiResponse({ status: 200, description: 'Daftar semua data pendidikan' })
  findAll() {
    return this.pendidikanService.findAll();
  }

  // Ambil data pendidikan berdasarkan ID
  @Get(':id')
  @ApiOperation({ summary: 'Mengambil data pendidikan berdasarkan ID' })
  @ApiResponse({ status: 200, description: 'Data pendidikan ditemukan' })
  @ApiResponse({ status: 404, description: 'Data pendidikan tidak ditemukan' })
  findOne(@Param('id') id: string) {
    return this.pendidikanService.findOne(id);
  }

  // Update data pendidikan
  @Put(':id')
  @ApiOperation({ summary: 'Memperbarui data pendidikan berdasarkan ID' })
  @ApiResponse({ status: 200, description: 'Data pendidikan berhasil diperbarui' })
  update(@Param('id') id: string, @Body() dto: UpdatePendidikanDto) {
    return this.pendidikanService.update(id, dto);
  }

  // Hapus data pendidikan
  @Delete(':id')
  @ApiOperation({ summary: 'Menghapus data pendidikan berdasarkan ID' })
  @ApiResponse({ status: 200, description: 'Data pendidikan berhasil dihapus' })
  remove(@Param('id') id: string) {
    return this.pendidikanService.remove(id);
  }
}

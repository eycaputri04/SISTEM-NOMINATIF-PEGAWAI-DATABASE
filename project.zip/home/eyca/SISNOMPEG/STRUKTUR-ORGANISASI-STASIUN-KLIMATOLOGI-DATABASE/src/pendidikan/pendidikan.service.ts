import { Injectable, BadRequestException } from '@nestjs/common';
import { supabase } from '../supabase/supabase.client';
import { CreatePendidikanDto } from './dto/create-pendidikan.dto';
import { UpdatePendidikanDto } from './dto/update-pendidikan.dto';
import { logAktivitas } from '../utils/logAktivitas';

@Injectable()
export class PendidikanService {
  private readonly table = 'pendidikan';

  /** CREATE Pendidikan */
  async create(createDto: CreatePendidikanDto) {
    const { data, error } = await supabase
      .from(this.table)
      .insert([createDto])
      .select()
      .maybeSingle();

    if (error) {
      throw new BadRequestException(`Gagal menambahkan pendidikan: ${error.message}`);
    }

    if (!data) {
      throw new BadRequestException('Data pendidikan gagal ditambahkan');
    }

    await logAktivitas(
      'Pendidikan',
      'Menambahkan data pendidikan',
      `Menambahkan pendidikan untuk pegawai ${createDto.Pegawai}`
    );

    return {
      message: 'Data pendidikan berhasil ditambahkan',
      data,
    };
  }

  /** UPDATE Pendidikan */
  async update(id: string, updateDto: UpdatePendidikanDto) {
    const { data, error } = await supabase
      .from(this.table)
      .update(updateDto)
      .eq('ID_Pendidikan', id)
      .select()
      .maybeSingle();

    if (error) {
      throw new BadRequestException(`Gagal memperbarui pendidikan: ${error.message}`);
    }

    if (!data) {
      throw new BadRequestException('Data pendidikan tidak ditemukan');
    }

    await logAktivitas(
      'Pendidikan',
      'Memperbarui data pendidikan',
      `Memperbarui pendidikan untuk pegawai ${data.Pegawai}`
    );

    return {
      message: 'Data pendidikan berhasil diperbarui',
      data,
    };
  }

  /** READ ALL Pendidikan */
  async findAll() {
    const { data, error } = await supabase.from(this.table).select('*');

    if (error) {
      throw new BadRequestException('Gagal mengambil data pendidikan');
    }

    return data;
  }

  /** READ ONE Pendidikan */
  async findOne(id: string) {
    const { data, error } = await supabase
      .from(this.table)
      .select('*')
      .eq('ID_Pendidikan', id)
      .maybeSingle();

    if (error) {
      throw new BadRequestException('Gagal mengambil data pendidikan');
    }

    if (!data) {
      throw new BadRequestException('Data pendidikan tidak ditemukan');
    }

    return data;
  }

  /** COUNT Total Data */
  async getCount() {
    const { count, error } = await supabase
      .from(this.table)
      .select('*', { count: 'exact', head: true });

    if (error) {
      throw new BadRequestException('Gagal mengambil total pendidikan');
    }

    return { count: count ?? 0 };
  }

  /** DELETE Pendidikan */
  async remove(id: string) {
    const { error } = await supabase.from(this.table).delete().eq('ID_Pendidikan', id);

    if (error) {
      throw new BadRequestException('Gagal menghapus data pendidikan');
    }

    await logAktivitas(
      'Pendidikan',
      'Menghapus data pendidikan',
      `Menghapus pendidikan dengan ID ${id}`
    );

    return { message: 'Data pendidikan berhasil dihapus' };
  }
}

import {
  Controller,
  Post,
  Get,
  Body,
  Param,
  Put,
  Delete,
  BadRequestException,
} from '@nestjs/common';
import { PegawaiService } from './pegawai.service';
import { CreatePegawaiDto } from './dto/create-pegawai.dto';
import { UpdatePegawaiDto } from './dto/update-pegawai.dto';
import { ApiTags, ApiOperation, ApiResponse } from '@nestjs/swagger';

@ApiTags('Pegawai')
@Controller('pegawai')
export class PegawaiController {
  constructor(private readonly pegawaiService: PegawaiService) {}

  @Post()
  async create(@Body() body: CreatePegawaiDto) {
    try {
      console.log('Data diterima:', body);
      const result = await this.pegawaiService.create(body);
      console.log('Hasil insert:', result);
      return result;
    } catch (error) {
      console.error('Error detail:', error);
      throw new BadRequestException('Gagal menambahkan pegawai');
    }
  }

  @Get()
  @ApiOperation({ summary: 'Mengambil semua data pegawai' })
  @ApiResponse({ status: 200, description: 'Daftar semua pegawai' })
  findAll() {
    return this.pegawaiService.findAll();
  }

  @Get('count')
  @ApiOperation({ summary: 'Mengambil jumlah total pegawai' })
  @ApiResponse({ status: 200, description: 'Total jumlah pegawai' })
  getCount() {
    return this.pegawaiService.getCount();
  }

  @Get(':nip')
  @ApiOperation({ summary: 'Mengambil data pegawai berdasarkan NIP' })
  @ApiResponse({ status: 200, description: 'Data pegawai ditemukan' })
  @ApiResponse({ status: 404, description: 'Pegawai tidak ditemukan' })
  findOne(@Param('nip') nip: string) {
    return this.pegawaiService.findOne(nip);
  }

  @Put(':nip')
  @ApiOperation({ summary: 'Memperbarui data pegawai berdasarkan NIP' })
  @ApiResponse({ status: 200, description: 'Pegawai berhasil diperbarui' })
  update(@Param('nip') nip: string, @Body() dto: UpdatePegawaiDto) {
    return this.pegawaiService.update(nip, dto);
  }

  @Delete(':nip')
  @ApiOperation({ summary: 'Menghapus pegawai berdasarkan NIP' })
  @ApiResponse({ status: 200, description: 'Pegawai berhasil dihapus' })
  remove(@Param('nip') nip: string) {
    return this.pegawaiService.remove(nip);
  }
}

import { Injectable, BadRequestException } from '@nestjs/common';
import { supabase } from '../supabase/supabase.client';
import { CreatePegawaiDto } from './dto/create-pegawai.dto';
import { UpdatePegawaiDto } from './dto/update-pegawai.dto';
import { logAktivitas } from '../utils/logAktivitas';

@Injectable()
export class PegawaiService {
  private readonly table = 'pegawai';

  async create(createPegawaiDto: CreatePegawaiDto) {
    const { data, error } = await supabase
      .from(this.table)
      .insert([createPegawaiDto])
      .select()
      .maybeSingle();

    if (error) {
      if (error.code === '23505') {
        throw new BadRequestException('NIP sudah terdaftar');
      }
      throw new BadRequestException(`Gagal menambahkan pegawai: ${error.message}`);
    }

    if (!data) {
      throw new BadRequestException('Pegawai gagal ditambahkan');
    }

    await logAktivitas(
      'Pegawai',
      'Menambahkan pegawai',
      `Menambahkan pegawai ${createPegawaiDto.Nama}`
    );

    return {
      message: 'Pegawai berhasil ditambahkan',
      data,
    };
  }

  async update(nip: string, updateDto: UpdatePegawaiDto) {
    const { data, error } = await supabase
      .from(this.table)
      .update(updateDto)
      .eq('NIP', nip)
      .select()
      .maybeSingle();

    if (error) {
      if (error.code === '23505') {
        throw new BadRequestException('NIP sudah terdaftar');
      }
      throw new BadRequestException(`Gagal memperbarui pegawai: ${error.message}`);
    }

    if (!data) {
      throw new BadRequestException('Pegawai tidak ditemukan');
    }

    await logAktivitas(
      'Pegawai',
      'Memperbarui pegawai',
      `Memperbarui pegawai ${data.Nama}`
    );

    return {
      message: 'Pegawai berhasil diperbarui',
      data,
    };
  }

  async findAll() {
    const { data, error } = await supabase.from(this.table).select('*');
    if (error) {
      throw new BadRequestException('Gagal mengambil data pegawai');
    }
    return data;
  }

  async findOne(nip: string) {
    const { data, error } = await supabase
      .from(this.table)
      .select('*')
      .eq('NIP', nip)
      .maybeSingle();

    if (error) {
      throw new BadRequestException('Gagal mengambil data pegawai');
    }

    if (!data) {
      throw new BadRequestException('Pegawai tidak ditemukan');
    }

    return data;
  }

  async getCount() {
    const { count, error } = await supabase
      .from(this.table)
      .select('*', { count: 'exact', head: true });

    if (error) {
      throw new BadRequestException('Gagal mengambil total pegawai');
    }

    return { count: count ?? 0 };
  }

  async remove(nip: string) {
    const { error } = await supabase.from(this.table).delete().eq('NIP', nip);

    if (error) {
      throw new BadRequestException('Gagal menghapus pegawai');
    }

    await logAktivitas(
      'Pegawai',
      'Menghapus pegawai',
      `Menghapus pegawai dengan NIP ${nip}`
    );

    return { message: 'Pegawai berhasil dihapus' };
  }
}
